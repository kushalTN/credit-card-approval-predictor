# train_model.py

import pandas as pd
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
import pickle

# Load dataset
df = pd.read_csv("D:\credit card prediction approval\cc_approvals.data", header=None)

# Name columns
df.columns = ['A' + str(i) for i in range(1, 5)] + ['Approval']

# Replace '?' with NaN
df.replace('?', np.nan, inplace=True)

# Encode all as numeric
le = LabelEncoder()
for col in df.columns:
    df[col] = df[col].astype(str)
    df[col] = le.fit_transform(df[col])

# Impute missing
imputer = SimpleImputer(strategy='most_frequent')
df = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# Features and target
X = df.drop('Approval', axis=1)
y = df['Approval']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train model with GridSearchCV
params = {
    'n_estimators': [100],
    'max_depth': [None, 10],
    'min_samples_split': [2, 5]
}
model = GridSearchCV(RandomForestClassifier(random_state=42), params, cv=5)
model.fit(X_scaled, y)

# Save model and scaler
pickle.dump(model.best_estimator_, open("model.pkl", "wb"))
pickle.dump(scaler, open("scaler.pkl", "wb"))

print("✅ Model trained and saved.")
