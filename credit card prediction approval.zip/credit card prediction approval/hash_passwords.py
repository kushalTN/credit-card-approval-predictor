import streamlit_authenticator as stauth

passwords = ["123", "admin123"]
hashed_pw = stauth.Hasher(passwords).generate()
print(hashed_pw)
