# streamlit_app.py

import streamlit as st
import numpy as np
import pickle

# Load model and scaler
model = pickle.load(open("model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

st.title("Credit Card Approval Predictor")

# Input form
inputs = []
for i in range(1, 5):
    val = st.text_input(f"Feature A{i}")
    inputs.append(val)

if st.button("Predict"):
    try:
        input_array = np.array(inputs).reshape(1, -1)
        input_array = scaler.transform(input_array)
        result = model.predict(input_array)
        if result[0] == 1:
            st.success("✅ Credit Card Approved")
        else:
            st.error("❌ Credit Card Denied")
    except:
        st.error("Please enter all fields as numbers.")
